DROP TABLE guest;
DROP TABLE room;
DROP TABLE room_type;
DROP TABLE booking;
DROP TABLE extra;
DROP TABLE rate;