DELETE FROM extra;
DELETE FROM booking; 
DELETE FROM rate;
DELETE FROM room;

DELETE FROM guest;
DELETE FROM room_type;