DROP TABLE extra;
DROP TABLE booking;
DROP TABLE room;
DROP TABLE rate;
DROP TABLE room_type;
DROP TABLE guest;



