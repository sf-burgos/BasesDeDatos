insert into Contenido values(N'sebastian Nieto', date'2019-03-06', N'sebasrechonchito.com');


insert into Opinion values (1, date'2019-03-06', N'P', N'divertido', null, N'juan.nieto-mo@mail.edu.co', N'Sebastian Nieto');


insert into Trata values(N':V','80',N'Programacion',N'PIM');


insert into Temporal values(127,N'i',N'Sebastian Nieto');


insert into Contenido values (N'Sebastian Nieto', date'2019-03-06', N'sebas.rechonchito.com', N'Z', N'python',N'Codigo');
