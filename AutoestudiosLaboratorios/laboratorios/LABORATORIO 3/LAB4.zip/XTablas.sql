drop table Autor;
drop table cliente;
drop table Compra;
drop table Editorial;
drop table informacion personal;
drop table libro;
drop table Tema;
drop table Referencia;
drop table Usuario;
