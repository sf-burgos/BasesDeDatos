delete from Autor;
delete from cliente;
delete from Compra;
delete from Editorial;
delete from informacion personal;
delete from libro;
delete from Referencia;
delete from Usuario;


